Exponential smoothing
===================
.. automodule:: hylia.exponential
   :members: