ARIMA
===================
.. automodule:: hylia.arima
   :members: