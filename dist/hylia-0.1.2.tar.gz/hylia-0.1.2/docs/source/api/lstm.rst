LSTM
===================
.. automodule:: hylia.lstm
   :members: