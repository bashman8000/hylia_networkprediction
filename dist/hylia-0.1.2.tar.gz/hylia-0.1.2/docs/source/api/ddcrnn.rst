DDCRNN
===================
.. automodule:: hylia.ddcrnn
   :members: