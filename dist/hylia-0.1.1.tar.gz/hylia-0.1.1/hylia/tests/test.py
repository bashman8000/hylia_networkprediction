from hylia.functions import sum
#from ..timeseries import TimeSeries

if __name__ == '__main__':
    print(f'sum of 2020 and 1 is : {sum(2020,1)}')
